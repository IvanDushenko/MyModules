DecoratorHelper
This class is intended for decorating called objects. Adds attributes that store arguments to an object and returns it.
