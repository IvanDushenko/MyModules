from setuptools import setup

setup(name='DecoratorHelper',
      version='1.1',
      description='This class is intended for decorating called objects.',
      packages=['DecoratorHelper'],
      author_email='ivandusheko@mail.ru',
      zip_safe=False)